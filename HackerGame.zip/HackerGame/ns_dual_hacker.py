import os
import time
import base64

TMP_DIR = os.environ.get("TMPDIR", "/tmp")
SYS1 = os.path.join(TMP_DIR, "system_target_1")
SYS2 = os.path.join(TMP_DIR, "system_target_2")
IP1_FILE = os.path.join(TMP_DIR, ".crypto_ip_1.txt")
IP2_FILE = os.path.join(TMP_DIR, ".crypto_ip_2.txt")

connected_node = None

def get_timer(filepath):
    if not os.path.exists(filepath):
        return 0
    try:
        with open(filepath, "r") as f:
            data = f.read().strip().split("|")
            return max(0, 34 - int(time.time() - float(data[2])))
    except:
        return 0

print("==========================================")
print("   [ DUAL TARGET HACKER SHELL - LEVEL 2 ] ")
print("==========================================")
print("Commands:")
print(" - ns1 <32|64>       : Crack Node 1")
print(" - ns2 <32|64>       : Crack Node 2")
print(" - connect <1|2> <IP>: Bind to Node 1 or Node 2")
print(" - rm target         : Wipe connected target")
print("==========================================\n")

while True:
    t1 = get_timer(IP1_FILE)
    t2 = get_timer(IP2_FILE)
    cmd = input(f"[N1:{t1}s | N2:{t2}s] HACKER-SHELL> ").strip()

    if cmd.startswith("ns1 ") or cmd.startswith("ns2 "):
        parts = cmd.split()
        target_num = parts[0][-1]
        mode_try = parts[1]
        target_file = IP1_FILE if target_num == "1" else IP2_FILE
        
        if os.path.exists(target_file):
            with open(target_file, "r") as f:
                enc, real_m, start_t = f.read().strip().split("|")
            if mode_try == real_m:
                dec = bytes.fromhex(enc).decode() if real_m == "32" else base64.b64decode(bytes.fromhex(enc).decode()).decode()
                print(f"[SUCCESS] Node {target_num} ({real_m}-bit) Cracked! IP -> \033[32m{dec}\033[0m")
            else:
                print(f"[FAILED] Wrong mode for Node {target_num}!")

    elif cmd.startswith("connect "):
        parts = cmd.split()
        if len(parts) == 3:
            connected_node = (parts[1], parts[2])
            print(f"[+] Connected to Node {parts[1]} IP: {parts[2]}")

    elif cmd == "rm target":
        if not connected_node:
            print("[ERROR] Connect to a node first!")
            continue
            
        n_num, n_ip = connected_node
        target_path = SYS1 if n_num == "1" else SYS2
        
        if os.path.exists(target_path):
            os.remove(target_path)
            print(f"[CRASH] Node {n_num} Destroyed successfully!")
            if not os.path.exists(SYS1) and not os.path.exists(SYS2):
                print("\n[🏆 VICTORY] BOTH NODES WIPED OUT! YOU WIN LEVEL 2!")
                break
        else:
            print(f"[ERROR] Node {n_num} already wiped!")

    else:
        print("Unknown Command.")
