import os
import sys
import subprocess

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def ar(text):
        return get_display(arabic_reshaper.reshape(text))
except:
    def ar(text):
        return text

def select_language():
    os.system("clear")
    print("==========================================")
    print("   [ SELECT LANGUAGE / اختر اللغة ]      ")
    print("==========================================")
    print("1. Arabic  / العربية")
    print("2. English / الإنجليزية")
    print("==========================================")
    return "ar" if input("\nChoose (1 or 2): ").strip() == "1" else "en"

def show_menu(lang):
    os.system("clear")
    print("==========================================")
    if lang == "ar":
        print(ar("   [ لعبة الهاكر - قائمة الصعوبة ]       "))
        print("==========================================")
        print(ar("1. وضع النوب   (سهل جداً)"))
        print(ar("2. وضع المتوسط (عادي)"))
        print(ar("3. وضع المحترف (صعب)"))
        print(ar("4. تغيير اللغة"))
        print(ar("5. خروج"))
    else:
        print("   [ HACKER GAME - DIFFICULTY MENU ]      ")
        print("==========================================")
        print("1. NOOB Mode   (Easy)")
        print("2. MEDIUM Mode (Normal)")
        print("3. PRO Mode    (Hard)")
        print("4. Change Language")
        print("5. Exit")
        
    choice = input("\nChoose (1-5): ").strip()
    
    # 1. وضع النوب
    if choice == "1":
        os.system("clear")
        print("\n" + "="*50)
        if lang == "ar":
            print(ar("😂 ههههههه رايح تلعب نوب؟"))
            print(ar("روح العب ببجي يا نوب، هذه لعبة المحترفين فقط! 😉"))
        else:
            print("😂 Haha! Going for Noob Mode?")
            print("Go play PUBG, noob! This game is for pros only! 😉")
        print("="*50 + "\n")
        
        prompt1 = ar("هل ما زلت مصراً على الإكمال في وضع النوب؟ (نعم/لا): ") if lang == "ar" else "Do you still want to continue in NOOB mode? (y/n): "
        ans = input(prompt1).strip().lower()
        
        if ans in ["نعم", "y", "yes"]:
            print("\n" + "🍼"*20)
            if lang == "ar":
                print(ar("👶 يا نونو روح استأذن من والدك قبل ما تلعب هذه اللعبة..."))
                print(ar("ليخاف عليك من الهاكر! 🕵️‍♂️💥"))
            else:
                print("👶 Oh little baby, go ask your dad for permission first...")
                print("Before the hackers scare you! 🕵️‍♂️💥")
            print("🍼"*20 + "\n")
            
        input(ar("اضغط Enter للعودة للقائمة...") if lang == "ar" else "Press Enter to return...")
        show_menu(lang)
        
    # 2. وضع المتوسط (صامت تماماً)
    elif choice == "2":
        subprocess.run([sys.executable, "ns_dual_hacker.py"])
        show_menu(lang)
        
    # 3. وضع المحترف / البرو (الخدعة الحماسية)
    elif choice == "3":
        subprocess.run([sys.executable, "ns_dual_hacker.py"])
        
        print("\n" + "🌟"*20)
        if lang == "ar":
            print(ar("🔥 أوه شاطر شاطر! قدرت تختتم كل المراحل بنجاح!"))
            print(ar("🚀 رح تبرمج معي اللعبة الجاية بس لما أرسل لك رسالة... انتظرني! 😉"))
        else:
            print("🔥 Oh clever clever! You finished all stages successfully!")
            print("🚀 You will develop the next game with me once I send you a message... Stay tuned! 😉")
        print("🌟"*20 + "\n")
        
        input(ar("اضغط Enter للعودة...") if lang == "ar" else "Press Enter to return...")
        show_menu(lang)
        
    elif choice == "4":
        show_menu(select_language())
    elif choice == "5":
        sys.exit(0)

if __name__ == "__main__":
    show_menu(select_language())
