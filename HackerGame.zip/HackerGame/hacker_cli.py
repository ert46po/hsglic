import time
import sys

def load_config():
    try:
        with open("config.txt", "r") as f:
            lines = f.readlines()
            print("[System] Config loaded successfully from config.txt")
            return [line.strip() for line in lines]
    except FileNotFoundError:
        return []

def hacker_game():
    config = load_config()
    print("\033[H\033[J", end="")
    print("=== HSGLIC CLI HACKER GAME ===")
    print("Select Difficulty:")
    print("1. Easy")
    print("2. Medium")
    print("3. Hard")
    
    choice = input("root@hsglic:~# select_level ")
    
    if choice == "1":
        print("\n[+] Entering Easy Mode...")
        print("Hint: Press [Ctrl + O] to trigger secret cheat from config!")
        cmd = input("root@easy:~# ")
        if cmd == "ctrl_o" and any("easy_cheat=ctrl_o" in c for c in config):
            print("\n[!] EASTER EGG UNLOCKED! Jumping straight to Hard Mode (Hardest Stage)...")
            time.sleep(1)
            hard_stage_final()
        else:
            print("Normal Easy progression...")
            
    elif choice == "2":
        print("\n[+] Entering Medium Mode...")
        print("Hint: Press [Ctrl + X1] to trigger secret cheat from config!")
        cmd = input("root@medium:~# ")
        if cmd == "ctrl_x1" and any("medium_cheat=ctrl_x1" in c for c in config):
            print("\n[!] EASTER EGG UNLOCKED! Bypassing all systems...")
            time.sleep(1)
            print("=== YOU WIN THE GAME INSTANTLY! ===")
        else:
            print("Normal Medium progression...")
            
    elif choice == "3":
        hard_stage_final()

def hard_stage_final():
    config = load_config()
    print("\n[!] WARNING: Entering Hard Mode (Final Stage)...")
    print("Hint: Press [Ctrl + O + C] to trigger secret cheat from config!")
    cmd = input("root@hard-final:~# ")
    if cmd == "ctrl_oc" and any("hard_cheat=ctrl_oc" in c for c in config):
        print("\n[***] MASTERMIND CHEAT ACTIVATED! Teleporting to the absolute last stage of Hard Mode...")
        time.sleep(1)
        print("=== MISSION ACCOMPLISHED: HARD MODE CONQUERED ===")
    else:
        print("Executing normal hard core tasks...")

if __name__ == "__main__":
    hacker_game()
