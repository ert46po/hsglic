import time
import random
import threading
import os
import base64

TMP_DIR = os.environ.get("TMPDIR", "/tmp")
SYS_TARGET1 = os.path.join(TMP_DIR, "system_target_1")
IP_FILE1 = os.path.join(TMP_DIR, ".crypto_ip_1.txt")
STATE_FILE = os.path.join(TMP_DIR, ".node1_state.txt")

with open(SYS_TARGET1, "w") as f:
    f.write("0" * 50)

def encrypt_ip(ip_str, mode):
    if mode == "32":
        return ip_str.encode().hex()
    else:
        b64 = base64.b64encode(ip_str.encode()).decode()
        return b64.encode().hex()

def node1_rotator():
    while True:
        mode = random.choice(["32", "64"])
        raw_ip = f"10.0.0.{random.randint(10, 250)}"
        encrypted = encrypt_ip(raw_ip, mode)
        
        # حفظ خيار Node 1 ليعرف Node 2 الخيار المعاكس
        with open(STATE_FILE, "w") as sf:
            sf.write(mode)
            
        with open(IP_FILE1, "w") as f:
            f.write(f"{encrypted}|{mode}|{time.time()}")
            
        time.sleep(34)

threading.Thread(target=node1_rotator, daemon=True).start()

print("==========================================")
print("  [ VICTIM NODE 1: Primary Active ]       ")
print("==========================================")

while True:
    if not os.path.exists(SYS_TARGET1):
        print("\n[CRITICAL] NODE 1 DESTROYED!")
        os._exit(0)
    time.sleep(1)
