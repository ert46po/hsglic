import time
import random
import threading
import os
import base64

TMP_DIR = os.environ.get("TMPDIR", "/tmp")
SYS_TARGET2 = os.path.join(TMP_DIR, "system_target_2")
IP_FILE2 = os.path.join(TMP_DIR, ".crypto_ip_2.txt")
STATE_FILE = os.path.join(TMP_DIR, ".node1_state.txt")

with open(SYS_TARGET2, "w") as f:
    f.write("0" * 50)

def encrypt_ip(ip_str, mode):
    if mode == "32":
        return ip_str.encode().hex()
    else:
        b64 = base64.b64encode(ip_str.encode()).decode()
        return b64.encode().hex()

def node2_rotator():
    while True:
        # قراءة خيار Node 1 واختيار العكس
        node1_mode = "32"
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, "r") as sf:
                    node1_mode = sf.read().strip()
            except:
                pass
                
        # إذا كان Node 1 يعمل بـ 64-bit فإن Node 2 سيعمل بـ 32-bit والعكس
        opposite_mode = "32" if node1_mode == "64" else "64"
        
        raw_ip = f"10.0.0.{random.randint(10, 250)}"
        encrypted = encrypt_ip(raw_ip, opposite_mode)
        
        with open(IP_FILE2, "w") as f:
            f.write(f"{encrypted}|{opposite_mode}|{time.time()}")
            
        time.sleep(34)

threading.Thread(target=node2_rotator, daemon=True).start()

print("==========================================")
print("  [ VICTIM NODE 2: Mirror Opposite Active ]")
print("==========================================")

while True:
    if not os.path.exists(SYS_TARGET2):
        print("\n[CRITICAL] NODE 2 DESTROYED!")
        os._exit(0)
    time.sleep(1)
