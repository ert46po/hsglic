#include <iostream>
#include <string>

using namespace std;

// دالة لتنظيف المسافات الزائدة من البداية والنهاية
string remove_spaces(const string& str) {
    size_t first = str.find_first_not_of(" \t\n\r");
    if (first == string::npos) return "";
    size_t last = str.find_last_not_of(" \t\n\r");
    return str.substr(first, (last - first + 1));
}

int main() {
    cout << "========================================" << endl;
    cout << "   مرحباً بك في محرك [ لغة العرب ]      " << endl;
    cout << "========================================" << endl;
    cout << "اكتب الأمر: اطبع(\"النص\"); " << endl;
    cout << "للخروج اكتب: خروج;" << endl << endl;

    string line;
    while (true) {
        cout << "عرب > ";
        if (!getline(cin, line)) break;

        // تنظيف السطر من المسافات الزائدة
        string clean_line = remove_spaces(line);

        // الخروج من البرنامج
        if (clean_line == "خروج;") {
            cout << "تم الإغلاق بنجاح." << endl;
            break;
        }

        // معالجة أمر الطباعة: اطبع("...")
        if (clean_line.rfind("اطبع", 0) == 0) {
            size_t start = clean_line.find("(\"");
            size_t end = clean_line.find("\")");

            if (start != string::npos && end != string::npos && end > start) {
                string text = clean_line.substr(start + 2, end - start - 2);
                cout << text << endl;
            } else {
                cout << "خطأ في الصيغة! اكتبها هكذا: اطبع(\"نص\");" << endl;
            }
        } 
        else if (!clean_line.empty()) {
            cout << "أمر غير معروف!" << endl;
        }
    }

    return 0;
}
